# afpy
A personal python package for increasing python efficiency by simplifying repeatable code.
